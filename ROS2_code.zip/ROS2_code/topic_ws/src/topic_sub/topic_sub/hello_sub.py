#!/usr/bin/env python3
# -*- coding: utf-8 -*-
 
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class Node_sub(Node):

    def __init__(self,name):
        super().__init__(name)
        self.object_sub = self.create_subscription(String, "chatter",self.listener_callback,10)

    def listener_callback(self,msg):
        self.get_logger().info("I recieved: %s" % msg.data)


def main(asgs=None):
    rclpy.init()
    node  = Node_sub("hello_sub")
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


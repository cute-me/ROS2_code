#!/usr/bin/env python3
# -*- coding: utf-8 -*-
 
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class Node_pub(Node):

    def __init__(self,name):
        super().__init__(name)
        self.object_pub = self.create_publisher(String, "chatter",10)
        self.timer = self.create_timer(2,self.timer_callback)

    def timer_callback(self):
        msg = String()
        msg.data = 'hello ,yinguotong!!'
        self.object_pub.publish(msg)
        self.get_logger().info("Publisher: %s" % msg.data)


def main(asgs=None):
    rclpy.init()
    node  = Node_pub("hello_pub")
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


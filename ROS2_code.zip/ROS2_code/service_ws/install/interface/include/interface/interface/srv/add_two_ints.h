// generated from rosidl_generator_c/resource/idl.h.em
// with input from interface:srv/AddTwoInts.idl
// generated code does not contain a copyright notice

#ifndef INTERFACE__SRV__ADD_TWO_INTS_H_
#define INTERFACE__SRV__ADD_TWO_INTS_H_

#include "interface/srv/detail/add_two_ints__struct.h"
#include "interface/srv/detail/add_two_ints__functions.h"
#include "interface/srv/detail/add_two_ints__type_support.h"

#endif  // INTERFACE__SRV__ADD_TWO_INTS_H_
